﻿using Huldra.Engine.Backends;
using System;
using System.Collections.Generic;
using System.Text;

namespace Huldra.Engine.Tests;

public sealed class BackendRuntimeTests
{
    [Fact]
    public void GetBestBackend_ShouldReturnSupportedBackend()
    {
        IBackend backend = BackendRuntime.Instance.GetBestBackend();

        Assert.NotNull(backend);
    }

    [Fact]
    public void ScalarBackend_ShouldBeAvailable()
    {
        IBackend backend =
            BackendRuntime.Instance.GetBackend("Scalar");

        Assert.Equal("Scalar", backend.Name);
    }

    [Fact]
    public void VectorBackend_ShouldBeAvailable()
    {
        IBackend backend =
            BackendRuntime.Instance.GetBackend("Vector");

        Assert.Equal("Vector", backend.Name);
    }

    [Fact]
    public void BackendLookup_ShouldBeCaseInsensitive()
    {
        IBackend backend =
            BackendRuntime.Instance.GetBackend("vEcToR");

        Assert.Equal("Vector", backend.Name);
    }

    [Fact]
    public void UnknownBackend_ShouldThrow()
    {
        Assert.Throws<KeyNotFoundException>(
            () => BackendRuntime.Instance.GetBackend(
                "DefinitelyNotABackend"));
    }

    [Fact]
    public void SupportedBackends_ShouldContainBuiltInBackends()
    {
        IReadOnlyCollection<string> backends =
            BackendRuntime.Instance.SupportedBackends;

        Assert.Contains("Scalar", backends);
        Assert.Contains("Vector", backends);
    }
}
