﻿using Huldra.Engine.Scalar;
using Huldra.Engine.Vector;
using System.Collections.Frozen;

namespace Huldra.Engine.Backends;

public sealed class BackendRuntime
{
    private static readonly Lazy<BackendRuntime> s_instance =
        new(static () => CreateDefault());

    public static BackendRuntime Instance => s_instance.Value;

    private readonly FrozenDictionary<string, BackendDescriptor> _backends;

    private BackendRuntime(
        FrozenDictionary<string, BackendDescriptor> backends)
    {
        _backends = backends;
    }

    private static BackendRuntime CreateDefault()
    {
        var backends = new Dictionary<string, BackendDescriptor>(
            StringComparer.OrdinalIgnoreCase);

        Register(
            backends,
            new BackendDescriptor(
                new ScalarBackend(),
                Priority: 0,
                IsSupported: static () => true));

        Register(
            backends,
            new BackendDescriptor(
                new VectorBackend(),
                Priority: 100,
                IsSupported: static () => true));

        return new BackendRuntime(
            backends.ToFrozenDictionary(StringComparer.OrdinalIgnoreCase));
    }

    private static void Register(
        Dictionary<string, BackendDescriptor> backends,
        BackendDescriptor descriptor)
    {
        ArgumentNullException.ThrowIfNull(descriptor);

        string name = descriptor.Backend.Name;

        if (string.IsNullOrWhiteSpace(name))
        {
            throw new InvalidOperationException(
                "A backend must provide a non-empty name.");
        }

        if (!backends.TryAdd(name, descriptor))
        {
            throw new InvalidOperationException(
                $"A backend named '{name}' is already registered.");
        }
    }

    public IBackend GetBestBackend()
    {
        BackendDescriptor? selected = null;

        foreach (BackendDescriptor descriptor in _backends.Values)
        {
            if (!descriptor.IsSupported())
                continue;

            if (selected is null ||
                descriptor.Priority > selected.Priority)
            {
                selected = descriptor;
            }
        }

        return selected?.Backend
            ?? throw new InvalidOperationException(
                "No supported backend is available.");
    }

    public IBackend GetBackend(string name)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(name);

        if (_backends.TryGetValue(name, out BackendDescriptor? descriptor))
        {
            if (!descriptor.IsSupported())
            {
                throw new NotSupportedException(
                    $"Backend '{name}' is not supported on this system.");
            }

            return descriptor.Backend;
        }

        throw new KeyNotFoundException(
            $"Backend '{name}' is not registered.");
    }

    public IReadOnlyCollection<string> SupportedBackends
    {
        get
        {
            var result = new List<string>();

            foreach (BackendDescriptor descriptor in _backends.Values)
            {
                if (descriptor.IsSupported())
                    result.Add(descriptor.Backend.Name);
            }

            return result;
        }
    }
}
