﻿namespace Huldra.Engine.Backends;

internal sealed record BackendDescriptor(
    IBackend Backend,
    int Priority,
    Func<bool> IsSupported);
