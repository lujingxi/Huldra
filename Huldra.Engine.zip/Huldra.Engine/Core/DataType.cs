﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Huldra.Engine.Core;

public enum DataType : uint
{
    F32 = 0,
    F16 = 1,
    Q4_0 = 2,
    Q4_1 = 3,
    Q5_0 = 4,
    Q5_1 = 5,
    Q8_0 = 6,
    Q8_1 = 7,
    Q2_K = 8,
    Q3_K = 9,
    Q4_K = 10,
    Q5_K = 11,
    Q6_K = 12,
    Q8_K = 13,
    IQ2_XXS = 14,
    IQ2_XS = 15,
    IQ3_XXS = 16,
    IQ1_S = 17,
    IQ4_NL = 18,
    IQ3_S = 19,
    IQ2_S = 20,
    IQ4_XS = 21,
    I8 = 22,
    I16 = 23,
    I32 = 24,
    I64 = 25,
    F64 = 26,
    IQ1_M = 27,
    BF16 = 28
}
