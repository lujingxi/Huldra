﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Huldra.Engine.Core;

/// <summary>
/// Defines the hardware-specific execution provider for tensor operations.
/// </summary>
public interface IBackend : IDisposable
{
    string Name { get; }

    /// <summary>
    /// Allocates memory for a new tensor on this backend (RAM or VRAM).
    /// </summary>
    ITensor AllocateTensor(string name, DataType dataType, params int[] shape);

    /// <summary>
    /// Matrix Multiplication: C = A * B
    /// </summary>
    void MatMul(ITensor tensorA, ITensor tensorB, ITensor tensorC);

    /// <summary>
    /// Element-wise Addition: C = A + B
    /// </summary>
    void Add(ITensor tensorA, ITensor tensorB, ITensor tensorC);

    /// <summary>
    /// Applies Root Mean Square Normalization.
    /// </summary>
    void RMSNorm(ITensor input, ITensor weight, ITensor output, float epsilon);

    /// <summary>
    /// Applies the SiLU (Sigmoid Linear Unit) activation function in-place.
    /// </summary>
    void SiLU(ITensor tensor);

    /// <summary>
    /// Synchronizes the backend queue (critical for asynchronous GPUs like CUDA).
    /// </summary>
    void Synchronize();
}
