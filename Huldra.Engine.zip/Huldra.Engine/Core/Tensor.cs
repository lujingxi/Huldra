﻿using System.Runtime.InteropServices;

namespace Huldra.Engine.Core;

public unsafe class Tensor : ITensor
{
    public string Name { get; }
    public DataType DataType { get; }
    public int[] Shape { get; }
    public long ElementCount { get; }
    public long MaxByteSize { get; }
    public IntPtr DataPointer { get; }

    private readonly bool _ownsMemory;

    // MMAP Wrapper Constructor
    public Tensor(string name, DataType dataType, int[] shape, IntPtr dataPointer, long maxByteSize)
    {
        Name = name;
        DataType = dataType;
        Shape = shape;
        ElementCount = shape.Aggregate(1L, (a, b) => a * b);
        DataPointer = dataPointer;
        MaxByteSize = maxByteSize; // Locked to exact MMAP view size
        _ownsMemory = false;
    }

    // Unmanaged Memory Allocation Constructor
    public Tensor(string name, DataType dataType, int[] shape)
    {
        Name = name;
        DataType = dataType;
        Shape = shape;
        ElementCount = shape.Aggregate(1L, (a, b) => a * b);
        _ownsMemory = true;

        long byteSize = CalculateByteSize(ElementCount, dataType);
        MaxByteSize = byteSize;

        void* ptr = NativeMemory.AllocZeroed((nuint)byteSize);
        DataPointer = (IntPtr)ptr;
    }

    private static long CalculateByteSize(long elementCount, DataType dataType)
    {
        return dataType switch
        {
            DataType.F32 => elementCount * 4,
            DataType.F16 => elementCount * 2,
            _ => throw new NotImplementedException($"Dynamic allocation for {dataType} is not supported.")
        };
    }

    public void Dispose()
    {
        if (_ownsMemory && DataPointer != IntPtr.Zero)
        {
            NativeMemory.Free((void*)DataPointer);
        }
    }
}
