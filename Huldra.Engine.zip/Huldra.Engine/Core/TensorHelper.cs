﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Huldra.Engine.Core;

public static class TensorHelper
{
    /// <summary>
    /// Master row stride calculator covering ALL GGML / GGUF data types with 32-byte alignment.
    /// Centralized to guarantee 100% synchronization between MMAP view creation and Backend pointer math.
    /// </summary>
    public static long CalculateRowStrideBytes(DataType dataType, int elementsPerRow, long alignment = 32)
    {
        long unalignedSize = dataType switch
        {
            DataType.F32 => elementsPerRow * 4L,
            DataType.F16 => elementsPerRow * 2L,
            DataType.BF16 => elementsPerRow * 2L,
            DataType.I16 => elementsPerRow * 2L,
            DataType.I8 => elementsPerRow * 1L,
            DataType.I32 => elementsPerRow * 4L,

            // Legacy Quants (Block size 32)
            DataType.Q4_0 => (elementsPerRow / 32L) * 18L,
            DataType.Q4_1 => (elementsPerRow / 32L) * 20L,
            DataType.Q5_0 => (elementsPerRow / 32L) * 22L,
            DataType.Q5_1 => (elementsPerRow / 32L) * 24L,
            DataType.Q8_0 => (elementsPerRow / 32L) * 34L,

            // K-Quants & I-Quants (Block size 256)
            DataType.Q2_K => (elementsPerRow / 256L) * 84L,
            DataType.Q3_K => (elementsPerRow / 256L) * 110L,
            DataType.Q4_K => (elementsPerRow / 256L) * 144L,
            DataType.Q5_K => (elementsPerRow / 256L) * 176L,
            DataType.Q6_K => (elementsPerRow / 256L) * 210L,
            DataType.Q8_K => (elementsPerRow / 256L) * 292L,
            DataType.IQ2_XXS => (elementsPerRow / 256L) * 66L,
            DataType.IQ2_XS => (elementsPerRow / 256L) * 74L,
            DataType.IQ3_XXS => (elementsPerRow / 256L) * 110L,
            DataType.IQ1_S => (elementsPerRow / 256L) * 56L,
            DataType.IQ4_NL => (elementsPerRow / 256L) * 144L,

            _ => elementsPerRow * 4L
        };

        long remainder = unalignedSize % alignment;
        if (remainder == 0) return unalignedSize;
        return unalignedSize + (alignment - remainder);
    }
}
