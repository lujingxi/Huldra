﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Huldra.Engine.Core;

/// <summary>
/// Provides methods to quantize and dequantize tensors.
/// </summary>
public interface IQuantizer
{
    /// <summary>
    /// Dequantizes a block of quantized data into 32-bit floats.
    /// </summary>
    void Dequantize(IntPtr source, Span<float> destination, int elementCount);
}
