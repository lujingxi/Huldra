﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Text;

namespace Huldra.Engine.Core;

/// <summary>
/// Unmanaged Memory Pool for Caching Key and Value vectors across sequence steps.
/// Accelerates auto-regressive generation from O(N^2) down to O(N).
/// </summary>
public unsafe class LlmKvCache : IDisposable
{
    private readonly int _layerCount;
    private readonly int _maxSeqLen;
    private readonly int _kvDim;

    private readonly float* _kData;
    private readonly float* _vData;

    public LlmKvCache(int layerCount, int maxSeqLen, int kvDim)
    {
        _layerCount = layerCount;
        _maxSeqLen = maxSeqLen;
        _kvDim = kvDim;

        long totalElements = (long)layerCount * maxSeqLen * kvDim;
        long byteSize = totalElements * sizeof(float);

        _kData = (float*)NativeMemory.AllocZeroed((nuint)byteSize);
        _vData = (float*)NativeMemory.AllocZeroed((nuint)byteSize);
    }

    private long GetOffset(int layer, int position)
    {
        return ((long)layer * _maxSeqLen + position) * _kvDim;
    }

    /// <summary>
    /// Safely stores Key and Value vectors using Slice bounds protection.
    /// </summary>
    public void Store(int layer, int position, ReadOnlySpan<float> key, ReadOnlySpan<float> value)
    {
        long offset = GetOffset(layer, position);

        Span<float> kDest = new Span<float>(_kData + offset, _kvDim);
        Span<float> vDest = new Span<float>(_vData + offset, _kvDim);

        // Safe bounds slice to prevent "Destination is too short" exception
        int kCopyLen = Math.Min(key.Length, kDest.Length);
        int vCopyLen = Math.Min(value.Length, vDest.Length);

        key.Slice(0, kCopyLen).CopyTo(kDest);
        value.Slice(0, vCopyLen).CopyTo(vDest);
    }

    public Span<float> GetKeySpan(int layer, int position)
    {
        long offset = GetOffset(layer, position);
        return new Span<float>(_kData + offset, _kvDim);
    }

    public Span<float> GetValueSpan(int layer, int position)
    {
        long offset = GetOffset(layer, position);
        return new Span<float>(_vData + offset, _kvDim);
    }

    public void Dispose()
    {
        if (_kData != null) NativeMemory.Free(_kData);
        if (_vData != null) NativeMemory.Free(_vData);
    }
}
