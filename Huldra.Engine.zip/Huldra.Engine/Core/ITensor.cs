﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Huldra.Engine.Core;

/// <summary>
/// Represents a multi-dimensional array used in neural network computations.
/// </summary>
public interface ITensor : IDisposable
{
    string Name { get; }
    DataType DataType { get; }

    /// <summary>
    /// The dimensions of the tensor (e.g., [BatchSize, SeqLen, HiddenSize]).
    /// </summary>
    int[] Shape { get; }

    /// <summary>
    /// Total number of elements in the tensor.
    /// </summary>
    long ElementCount { get; }

    /// <summary>
    /// Physical MMAP View Capacity Limit
    /// </summary>
    long MaxByteSize { get; }

    /// <summary>
    /// A raw pointer to the underlying memory (MMAP or VRAM).
    /// </summary>
    IntPtr DataPointer { get; }
}
