﻿using Huldra.Engine.Core;
using Huldra.Engine.Gguf;
using System;
using System.Collections.Generic;
using System.Text;

namespace Huldra.Engine.Models;

/// <summary>
/// Loads and maps Qwen/Llama architecture tensors from MMAP to C# ITensor objects.
/// </summary>
public class QwenModel
{
    public ITensor? TokenEmbeddings { get; private set; }
    public ITensor? OutputNorm { get; private set; }
    public ITensor? Output { get; private set; }

    public TransformerBlock[] Blocks { get; private set; }

    public uint ContextLength { get; }
    public uint HiddenSize { get; }
    public uint HeadCount { get; }

    public QwenModel(GgufReader reader)
    {
        string arch = reader.GetMetadata<string>("general.architecture") ?? "qwen2";
        ContextLength = reader.GetMetadata<uint>($"{arch}.context_length");
        HiddenSize = reader.GetMetadata<uint>($"{arch}.embedding_length");
        uint blockCount = reader.GetMetadata<uint>($"{arch}.block_count");
        HeadCount = reader.GetMetadata<uint>($"{arch}.attention.head_count");

        Blocks = new TransformerBlock[blockCount];
        for (int i = 0; i < blockCount; i++) Blocks[i] = new TransformerBlock(i);

        foreach (var tInfo in reader.Tensors)
        {
            int[] shape = tInfo.Shape.Select(s => (int)s).ToArray();
            IntPtr ptr = reader.GetTensorDataPointer(tInfo);
            var tensor = new Tensor(tInfo.Name, tInfo.Type, shape, ptr, tInfo.MaxByteSize);

            if (tInfo.Name == "token_embd.weight") TokenEmbeddings = tensor;
            else if (tInfo.Name == "output_norm.weight") OutputNorm = tensor;
            else if (tInfo.Name == "output.weight") Output = tensor;
            else if (tInfo.Name.StartsWith("blk."))
            {
                var parts = tInfo.Name.Split('.');
                if (parts.Length >= 3 && int.TryParse(parts[1], out int layerIdx))
                {
                    string component = parts[2];

                    if (component == "attn_norm") Blocks[layerIdx].AttnNorm = tensor;
                    else if (component == "attn_qkv") Blocks[layerIdx].AttnQkv = tensor;
                    else if (component == "attn_q") Blocks[layerIdx].AttnQ = tensor;
                    else if (component == "attn_k") Blocks[layerIdx].AttnK = tensor;
                    else if (component == "attn_v") Blocks[layerIdx].AttnV = tensor;
                    else if (component == "attn_output" || component == "attn_out" || component == "attn_proj") Blocks[layerIdx].AttnOut = tensor;
                    else if (component == "attn_q_norm") Blocks[layerIdx].AttnQNorm = tensor;
                    else if (component == "attn_k_norm") Blocks[layerIdx].AttnKNorm = tensor;

                    else if (component == "ffn_norm" || component == "post_attention_norm") Blocks[layerIdx].FfnNorm = tensor;

                    else if (component == "ffn_gate") Blocks[layerIdx].FfnGate = tensor;
                    else if (component == "ffn_up") Blocks[layerIdx].FfnUp = tensor;
                    else if (component == "ffn_down") Blocks[layerIdx].FfnDown = tensor;
                }
            }
        }
    }
}
