﻿using System.Text;
using System.Text.RegularExpressions;
using Huldra.Engine.Gguf;

namespace Huldra.Engine.Models;

/// <summary>
/// BPE Tokenizer with strict Special Control Token mapping support.
/// </summary>
public class LlmTokenizer
{
    private readonly string[] _vocab;
    private readonly Dictionary<string, int> _tokenToId = new(StringComparer.Ordinal);
    private readonly Dictionary<string, int> _mergeRanks = new(StringComparer.Ordinal);

    public int BosTokenId { get; }
    public int EosTokenId { get; }

    public LlmTokenizer(GgufReader reader)
    {
        // 1. Read Tokens Vocabulary
        var tokensObj = reader.GetMetadata<object[]>("tokenizer.ggml.tokens");
        if (tokensObj == null)
            throw new InvalidDataException("Vocabulary missing in GGUF metadata.");

        _vocab = new string[tokensObj.Length];
        for (int i = 0; i < tokensObj.Length; i++)
        {
            string t = tokensObj[i].ToString() ?? "";
            _vocab[i] = t;
            _tokenToId[t] = i;
        }

        // ========================================================
        // CRITICAL FIX: DYNAMIC BYTE 10 (\n) VOCABULARY SCANNER
        // Finds the exact Token ID for newline, whether stored as "\n", "<0x0A>", or "Ċ"
        // ========================================================
        int newlineId = FindNewlineTokenId();
        if (newlineId != -1)
        {
            _tokenToId["\n"] = newlineId;
            Console.WriteLine($"[Tokenizer] Dynamic Scan Success: Mapped '\\n' -> Token ID {newlineId} (\"{_vocab[newlineId]}\")");
        }
        else
        {
            Console.WriteLine("[Tokenizer Warning] Could not find explicit newline token in vocabulary.");
        }

        // 2. Load BPE Merge Pairs
        var mergesObj = reader.GetMetadata<object[]>("tokenizer.ggml.merges");
        if (mergesObj != null)
        {
            for (int i = 0; i < mergesObj.Length; i++)
            {
                string mergeStr = mergesObj[i].ToString() ?? "";
                _mergeRanks[mergeStr] = i;
            }
        }

        // 3. Extract Special Tokens
        BosTokenId = reader.GetMetadata<uint?>("tokenizer.ggml.bos_token_id") != null
            ? (int)reader.GetMetadata<uint>("tokenizer.ggml.bos_token_id") : 1;

        EosTokenId = reader.GetMetadata<uint?>("tokenizer.ggml.eos_token_id") != null
            ? (int)reader.GetMetadata<uint>("tokenizer.ggml.eos_token_id") : 151645;
    }

    private int FindNewlineTokenId()
    {
        // Strategy 1: Check known string representations
        string[] candidates = ["\n", "<0x0A>", "<0x0a>", "Ċ", "Ġ\n"];
        foreach (var cand in candidates)
        {
            if (_tokenToId.TryGetValue(cand, out int id))
            {
                return id;
            }
        }

        // Strategy 2: Scan vocabulary for single byte 0x0A (ASCII 10)
        for (int i = 0; i < _vocab.Length; i++)
        {
            byte[] bytes = Encoding.UTF8.GetBytes(_vocab[i]);
            if (bytes.Length == 1 && bytes[0] == 10)
            {
                return i;
            }
        }

        return -1;
    }

    public string ApplyChatTemplate(string userPrompt, string systemPrompt = "You are AI.")
    {
        return $"<|im_start|>system\n{systemPrompt}<|im_end|>\n<|im_start|>user\n{userPrompt}<|im_end|>\n<|im_start|>assistant";
    }

    public List<int> Tokenize(string text)
    {
        if (string.IsNullOrEmpty(text)) return [];

        var result = new List<int>();

        // Regex pattern isolating special control tags and newlines
        string pattern = @"(<\|im_start\|>|<\|im_end\|>|<\|endoftext\|>|\n)";
        var parts = Regex.Split(text, pattern);

        foreach (var part in parts)
        {
            if (string.IsNullOrEmpty(part)) continue;

            if (_tokenToId.TryGetValue(part, out int specialId))
            {
                result.Add(specialId);
            }
            else
            {
                result.AddRange(TokenizeStandardText(part));
            }
        }

        return result;
    }

    private List<int> TokenizeStandardText(string text)
    {
        string formattedText = text.Replace(" ", "Ġ");
        var symbols = formattedText.Select(c => c.ToString()).ToList();

        while (symbols.Count > 1)
        {
            int bestPairIndex = -1;
            int bestRank = int.MaxValue;

            for (int i = 0; i < symbols.Count - 1; i++)
            {
                string pairKey = $"{symbols[i]} {symbols[i + 1]}";
                if (_mergeRanks.TryGetValue(pairKey, out int rank))
                {
                    if (rank < bestRank)
                    {
                        bestRank = rank;
                        bestPairIndex = i;
                    }
                }
            }

            if (bestPairIndex == -1) break;

            string mergedSymbol = symbols[bestPairIndex] + symbols[bestPairIndex + 1];
            symbols[bestPairIndex] = mergedSymbol;
            symbols.RemoveAt(bestPairIndex + 1);
        }

        var tokenIds = new List<int>();
        foreach (var sym in symbols)
        {
            if (_tokenToId.TryGetValue(sym, out int id))
            {
                tokenIds.Add(id);
            }
            else
            {
                foreach (char c in sym)
                {
                    if (_tokenToId.TryGetValue(c.ToString(), out int charId))
                    {
                        tokenIds.Add(charId);
                    }
                }
            }
        }

        return tokenIds;
    }

    public string Detokenize(int tokenId)
    {
        if (tokenId < 0 || tokenId >= _vocab.Length) return "";

        string tokenStr = _vocab[tokenId];
        tokenStr = tokenStr.Replace("Ġ", " ").Replace(" ", " ");
        tokenStr = tokenStr.Replace("<0x0A>", "\n").Replace("Ċ", "\n");

        return tokenStr;
    }

    public int GetVocabSize() => _vocab.Length;
}
