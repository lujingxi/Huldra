﻿using Huldra.Engine.Core;
using System;
using System.Collections.Generic;
using System.Text;

namespace Huldra.Engine.Models;

/// <summary>
/// Represents a single Transformer layer (Block) in Qwen.
/// </summary>
public class TransformerBlock
{
    public int LayerIndex { get; }

    // Attention components
    public ITensor? AttnNorm { get; set; }
    public ITensor? AttnQkv { get; set; }  // Fused QKV
    public ITensor? AttnQ { get; set; }    // Separated Q
    public ITensor? AttnK { get; set; }    // Separated K
    public ITensor? AttnV { get; set; }    // Separated V
    public ITensor? AttnGate { get; set; } // <--- NEW: Attention Gate for Qwen Gated Attention
    public ITensor? AttnOut { get; set; }  // True Output projection

    // QK-Norm Tensors
    public ITensor? AttnQNorm { get; set; }
    public ITensor? AttnKNorm { get; set; }

    // FFN components
    public ITensor? FfnNorm { get; set; }
    public ITensor? FfnGate { get; set; }
    public ITensor? FfnUp { get; set; }
    public ITensor? FfnDown { get; set; }

    public TransformerBlock(int index)
    {
        LayerIndex = index;
    }
}
