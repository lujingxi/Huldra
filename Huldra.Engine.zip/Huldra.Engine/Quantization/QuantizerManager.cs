﻿using System.Reflection;
using Huldra.Engine.Core;

namespace Huldra.Engine.Quantization;

/// <summary>
/// A unified, singleton manager that handles registration and fallback routing for all quantizers across different backends.
/// </summary>
public class QuantizerManager
{
    // Singleton Instance
    public static QuantizerManager Instance { get; } = new QuantizerManager();

    // Mapping: BackendName -> (DataType -> IQuantizer)
    private readonly Dictionary<string, Dictionary<DataType, IQuantizer>> _registry = new(StringComparer.OrdinalIgnoreCase);

    private QuantizerManager()
    {
        // Private constructor to enforce Singleton pattern
    }

    /// <summary>
    /// Forces a backend to register its quantizers during initialization.
    /// </summary>
    public void RegisterQuantizers(string backendName, Assembly assembly, string targetNamespace)
    {
        if (!_registry.ContainsKey(backendName))
        {
            _registry[backendName] = new Dictionary<DataType, IQuantizer>();
        }

        var quantizerTypes = assembly.GetTypes()
            .Where(t => t.IsClass && !t.IsAbstract && typeof(IQuantizer).IsAssignableFrom(t))
            .Where(t => t.Namespace != null && t.Namespace.StartsWith(targetNamespace, StringComparison.OrdinalIgnoreCase));

        foreach (var type in quantizerTypes)
        {
            var attribute = type.GetCustomAttribute<QuantizerAttribute>();
            if (attribute == null)
            {
                throw new InvalidOperationException(
                    $"[Architecture Violation] '{type.FullName}' is missing [Quantizer(DataType)] attribute.");
            }

            var instance = (IQuantizer)Activator.CreateInstance(type)!;
            _registry[backendName][attribute.SupportedType] = instance;

            Console.WriteLine($"[QuantizerManager] Registered: {type.Name} -> [{backendName} | {attribute.SupportedType}]");
        }
    }

    /// <summary>
    /// Retrieves a quantizer. Throws in DEBUG if missing. Falls back to Scalar in RELEASE.
    /// </summary>
    public IQuantizer GetQuantizer(string backendName, DataType dataType)
    {
        // 1. Try to find the optimized quantizer for the specific backend
        if (_registry.TryGetValue(backendName, out var backendDict))
        {
            if (backendDict.TryGetValue(dataType, out var quantizer))
            {
                return quantizer;
            }
        }

        // 2. Not found. Handle based on Build Configuration
#if DEBUG
        // In DEBUG mode, we strictly enforce implementation to alert the developer
        if (!backendName.Equals("Scalar", StringComparison.OrdinalIgnoreCase))
        {
            throw new NotSupportedException(
                $"[DEBUG Strict Mode] The backend '{backendName}' does not support Quantizer '{dataType}'. " +
                $"Please implement it, or test in Release mode to observe the Scalar fallback behavior.");
        }
#endif

        // 3. Fallback to Scalar (CPU) implementation
        if (!backendName.Equals("Scalar", StringComparison.OrdinalIgnoreCase))
        {
            Console.WriteLine($"[QuantizerManager Warning] Backend '{backendName}' missing '{dataType}' quantizer. Falling back to Scalar (CPU).");
        }

        if (_registry.TryGetValue("Scalar", out var scalarDict))
        {
            if (scalarDict.TryGetValue(dataType, out var scalarQuantizer))
            {
                return scalarQuantizer;
            }
        }

        // 4. Absolute failure: Not even Scalar supports it
        throw new NotSupportedException($"Critical Error: No quantizer found for '{dataType}', not even in the Scalar fallback registry.");
    }
}
