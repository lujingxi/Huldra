﻿using Huldra.Engine.Core;

namespace Huldra.Engine.Quantization;

[AttributeUsage(AttributeTargets.Class, Inherited = false)]
public class QuantizerAttribute : Attribute
{
    public DataType SupportedType { get; }

    public QuantizerAttribute(DataType supportedType)
    {
        SupportedType = supportedType;
    }
}
