﻿using System.Runtime.InteropServices;

namespace Huldra.Engine.Quantization;

/// <summary>
/// C# representations of ggml_type block structures.
/// StructLayout(LayoutKind.Sequential, Pack = 1) ensures perfect memory alignment.
/// </summary>

// Standard 32-bit Float Block
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BlockF32
{
    public float F;
}

// Q8_0 Block -> PascalCase: BlockQ80
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public unsafe struct BlockQ80
{
    public ushort Delta; // Float16 scale
    public fixed sbyte Quants[32];
}

// Q8_K Block -> Exactly 292 bytes per 256 elements
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public unsafe struct BlockQ8K
{
    public float D;                 // 4 bytes float32 super-scale
    public fixed sbyte Quants[256]; // 256 bytes (8-bit quants)
    public fixed short Bsums[16];   // 32 bytes (block sums)
}

// Q6_K Block -> PascalCase: BlockQ6K (Exactly 210 bytes)
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public unsafe struct BlockQ6K
{
    public fixed byte Ql[128];      // 128 bytes (lower 4 bits of 256 elements)
    public fixed byte Qh[64];       // 64 bytes (upper 2 bits of 256 elements)
    public fixed sbyte Scales[16];  // 16 bytes (8-bit scales)
    public ushort D;                // 2 bytes (float16 global scale)
}

// Q4_K Block -> Exactly 144 bytes per 256 elements
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public unsafe struct BlockQ4K
{
    public ushort D;                // 2 bytes float16 scale
    public ushort Dmin;             // 2 bytes float16 min
    public fixed byte Scales[12];   // 12 bytes packed scales
    public fixed byte Quants[128];  // 128 bytes (256 4-bit quants)
}

// IQ2_XXS Block -> Exactly 66 bytes (2 bytes Float16 'D' + 64 bytes Quants)
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public unsafe struct BlockIq2Xxs
{
    public ushort Delta;            // 2 bytes (Float16 super-scale)
    public fixed ushort Quants[32]; // 64 bytes (32 x 16-bit packed grid indices)
}
