﻿using System.Buffers;
using System.Runtime.InteropServices;
using Huldra.Engine.Core;
using Huldra.Engine.Quantization;

namespace Huldra.Engine.Backends.Scalar;

public class ScalarBackend : IBackend
{
    public string Name => "Scalar";
    private const float MAX_SAFE_FLOAT = 1E+20f; // Safe bound far below 3.4E+38 to prevent Infinity

    public ScalarBackend()
    {
        string targetNamespace = typeof(ScalarBackend).Namespace ?? string.Empty;
        QuantizerManager.Instance.RegisterQuantizers(this.Name, typeof(ScalarBackend).Assembly, targetNamespace);
    }

    public ITensor AllocateTensor(string name, DataType dataType, params int[] shape)
    {
        return new Tensor(name, dataType, shape);
    }

    public void DequantizeTensor(ITensor tensor, Span<float> dstSpan)
    {
        var quantizer = QuantizerManager.Instance.GetQuantizer(this.Name, tensor.DataType);
        quantizer.Dequantize(tensor.DataPointer, dstSpan, (int)tensor.ElementCount);
    }

    public unsafe void QuantizedMatVecMul(ITensor vectorA, ITensor quantizedWeightB, ITensor outputC)
    {
        float* A = (float*)vectorA.DataPointer;
        float* C = (float*)outputC.DataPointer;

        int rowLengthK = quantizedWeightB.Shape[0];
        int numRowsN = (int)(quantizedWeightB.ElementCount / rowLengthK);

        long bytesPerRow = TensorHelper.CalculateRowStrideBytes(quantizedWeightB.DataType, rowLengthK);
        byte* tensorStart = (byte*)quantizedWeightB.DataPointer;
        byte* tensorEnd = tensorStart + quantizedWeightB.MaxByteSize;

        long outputCapacity = outputC.ElementCount;

        Parallel.For(
            0,
            numRowsN,
            () => ArrayPool<float>.Shared.Rent(rowLengthK),
            (n, loopState, weightRowArray) =>
            {
                if (n >= outputCapacity) return weightRowArray;

                byte* rowPtr = tensorStart + (n * bytesPerRow);

                if ((byte*)rowPtr + bytesPerRow > tensorEnd || rowPtr < tensorStart)
                {
                    C[n] = 0f;
                    return weightRowArray;
                }

                Span<float> weightRow = weightRowArray.AsSpan(0, rowLengthK);

                try
                {
                    using var tempRowTensor = new Tensor("temp_row", quantizedWeightB.DataType, [rowLengthK], (IntPtr)rowPtr, bytesPerRow);
                    DequantizeTensor(tempRowTensor, weightRow);

                    float sum = 0f;
                    for (int k = 0; k < rowLengthK; k++)
                    {
                        sum += A[k] * weightRow[k];
                    }

                    // Pure clamp to prevent hitting Infinity, no zeroing
                    C[n] = Math.Clamp(sum, -MAX_SAFE_FLOAT, MAX_SAFE_FLOAT);
                }
                catch
                {
                    C[n] = 0f;
                }

                return weightRowArray;
            },
            weightRowArray =>
            {
                ArrayPool<float>.Shared.Return(weightRowArray);
            });
    }

    public unsafe void RMSNorm(ITensor input, ITensor weight, ITensor output, float epsilon = 1e-6f)
    {
        float* x = (float*)input.DataPointer;
        float* w = (float*)weight.DataPointer;
        float* outPtr = (float*)output.DataPointer;
        int inputN = (int)input.ElementCount;
        int weightN = (int)weight.ElementCount;

        if (inputN == 0 || weightN == 0) return;

        float sumOfSquares = 0f;
        for (int i = 0; i < inputN; i++)
        {
            sumOfSquares += x[i] * x[i];
        }

        // Prevent division by zero or NaN propagation
        if (sumOfSquares <= 0f || float.IsNaN(sumOfSquares)) sumOfSquares = 1.0f;

        float rms = MathF.Sqrt((sumOfSquares / inputN) + epsilon);
        float scale = 1.0f / rms;

        bool isZeroCentered = MathF.Abs(w[0]) < 1e-5f && MathF.Abs(w[1 % weightN]) < 1e-5f;

        Parallel.For(0, inputN, i =>
        {
            float weightFactor = isZeroCentered ? (1.0f + w[i % weightN]) : w[i % weightN];
            float val = x[i] * scale * weightFactor;

            outPtr[i] = Math.Clamp(val, -MAX_SAFE_FLOAT, MAX_SAFE_FLOAT);
        });
    }

    public unsafe void RoPE(ITensor tensor, int position, int headCount, float ropeBase = 1000000.0f)
    {
        float* ptr = (float*)tensor.DataPointer;
        int totalElements = (int)tensor.ElementCount;

        int headDim = totalElements / headCount;
        int halfDim = headDim / 2;

        Parallel.For(0, headCount, h =>
        {
            float* headPtr = ptr + (h * headDim);

            for (int i = 0; i < halfDim; i++)
            {
                float theta = 1.0f / MathF.Pow(ropeBase, (2.0f * i) / headDim);
                float angle = position * theta;
                float cos = MathF.Cos(angle);
                float sin = MathF.Sin(angle);

                float x1 = headPtr[i];
                float x2 = headPtr[i + halfDim];

                float r1 = x1 * cos - x2 * sin;
                float r2 = x1 * sin + x2 * cos;

                headPtr[i] = Math.Clamp(r1, -MAX_SAFE_FLOAT, MAX_SAFE_FLOAT);
                headPtr[i + halfDim] = Math.Clamp(r2, -MAX_SAFE_FLOAT, MAX_SAFE_FLOAT);
            }
        });
    }

    public unsafe void ComputeAttentionWithKvCache(
        ITensor queryTensor, LlmKvCache kvCache, int layerIndex,
        int currentPosition, int numQueryHeads, ITensor outputTensor)
    {
        float* Q = (float*)queryTensor.DataPointer;
        float* Out = (float*)outputTensor.DataPointer;

        int totalDim = (int)queryTensor.ElementCount;
        int headDim = 128;
        float scale = 1.0f / MathF.Sqrt(headDim);

        Parallel.For(0, numQueryHeads, h =>
        {
            float* qHead = Q + (h * headDim);
            float* outHead = Out + (h * headDim);

            Span<float> scores = stackalloc float[currentPosition + 1];

            for (int pos = 0; pos <= currentPosition; pos++)
            {
                Span<float> kSpan = kvCache.GetKeySpan(layerIndex, pos);
                int numKvHeads = kSpan.Length / headDim;
                int gqaRatio = Math.Max(1, numQueryHeads / (numKvHeads > 0 ? numKvHeads : 1));
                int kvHead = h / gqaRatio;
                int kOffset = kvHead * headDim;

                float score = 0f;
                for (int d = 0; d < headDim && (kOffset + d) < kSpan.Length; d++)
                {
                    score += qHead[d] * kSpan[kOffset + d];
                }
                scores[pos] = Math.Clamp(score * scale, -MAX_SAFE_FLOAT, MAX_SAFE_FLOAT);
            }

            float maxScore = float.MinValue;
            for (int pos = 0; pos <= currentPosition; pos++)
            {
                if (scores[pos] > maxScore) maxScore = scores[pos];
            }

            float sumExp = 0f;
            for (int pos = 0; pos <= currentPosition; pos++)
            {
                float expVal = MathF.Exp(scores[pos] - maxScore);
                scores[pos] = expVal;
                sumExp += expVal;
            }

            float invSum = sumExp == 0f ? 1.0f : (1.0f / sumExp);
            for (int pos = 0; pos <= currentPosition; pos++)
            {
                scores[pos] *= invSum;
            }

            for (int d = 0; d < headDim; d++) outHead[d] = 0f;

            for (int pos = 0; pos <= currentPosition; pos++)
            {
                float prob = scores[pos];
                Span<float> vSpan = kvCache.GetValueSpan(layerIndex, pos);

                int numKvHeads = vSpan.Length / headDim;
                int gqaRatio = Math.Max(1, numQueryHeads / (numKvHeads > 0 ? numKvHeads : 1));
                int kvHead = h / gqaRatio;
                int vOffset = kvHead * headDim;

                for (int d = 0; d < headDim && (vOffset + d) < vSpan.Length; d++)
                {
                    outHead[d] += prob * vSpan[vOffset + d];
                }
            }
        });
    }

    public unsafe void Add(ITensor tensorA, ITensor tensorB, ITensor tensorC)
    {
        float* A = (float*)tensorA.DataPointer;
        float* B = (float*)tensorB.DataPointer;
        float* C = (float*)tensorC.DataPointer;
        int n = (int)tensorA.ElementCount;

        Parallel.For(0, n, i => { C[i] = Math.Clamp(A[i] + B[i], -MAX_SAFE_FLOAT, MAX_SAFE_FLOAT); });
    }

    public unsafe void SiLU(ITensor tensor)
    {
        float* x = (float*)tensor.DataPointer;
        int n = (int)tensor.ElementCount;

        Parallel.For(0, n, i =>
        {
            float val = x[i];
            x[i] = Math.Clamp(val / (1.0f + MathF.Exp(-val)), -MAX_SAFE_FLOAT, MAX_SAFE_FLOAT);
        });
    }

    public unsafe void ElementWiseMul(ITensor tensorA, ITensor tensorB, ITensor tensorC)
    {
        float* A = (float*)tensorA.DataPointer;
        float* B = (float*)tensorB.DataPointer;
        float* C = (float*)tensorC.DataPointer;
        int n = (int)tensorA.ElementCount;

        Parallel.For(0, n, i => { C[i] = Math.Clamp(A[i] * B[i], -MAX_SAFE_FLOAT, MAX_SAFE_FLOAT); });
    }

    public unsafe void MatMul(ITensor tensorA, ITensor tensorB, ITensor tensorC) { }
    public void Synchronize() { }
    public void Dispose() { }
}
