﻿using Huldra.Engine.Core;
using Huldra.Engine.Quantization;

namespace Huldra.Engine.Backends.Scalar.Quantizers;

[Quantizer(DataType.IQ2_XXS)]
public class QuantizerIq2Xxs : IQuantizer
{
    public unsafe void Dequantize(IntPtr srcPointer, Span<float> dstSpan, int elementCount)
    {
        if (srcPointer == IntPtr.Zero) return;

        int blockSize = 256;
        int nb = elementCount / blockSize;
        BlockIq2Xxs* x = (BlockIq2Xxs*)srcPointer;

        fixed (byte* gridPtr = Iq2XxsCodebook.Grid)
        fixed (byte* signsPtr = Iq2XxsCodebook.KSignsIq2Xs)
        fixed (float* y = dstSpan)
        {
            for (int i = 0; i < nb; i++)
            {
                float d = (float)BitConverter.UInt16BitsToHalf(x[i].Delta);

                // Block-level sanitization: Zero out ONLY this bad block!
                if (float.IsNaN(d) || float.IsInfinity(d))
                {
                    float* y_bad = y + i * blockSize;
                    for (int j = 0; j < blockSize; j++) y_bad[j] = 0f;
                    continue;
                }

                ushort* qs = x[i].Quants;
                uint aux32_1 = ((uint)qs[3] << 16) | qs[2];
                float db = d * (0.5f + (aux32_1 >> 28)) * 0.25f;

                float* grid_y = y + i * blockSize;

                for (int j = 0; j < 32; ++j)
                {
                    ushort aux = qs[j];
                    int gridIdx = aux & 255;
                    int signIdx = aux >> 9;

                    byte* subGrid = gridPtr + (gridIdx * 8);
                    byte signMask = signsPtr[signIdx];

                    float* sub_y = grid_y + 8 * j;

                    for (int l = 0; l < 8; ++l)
                    {
                        byte gridVal = subGrid[l];
                        bool isNegative = (signMask & (1 << l)) != 0;

                        sub_y[l] = db * (isNegative ? -gridVal : gridVal);
                    }
                }
            }
        }
    }
}

