﻿using Huldra.Engine.Core;
using Huldra.Engine.Quantization;

namespace Huldra.Engine.Backends.Scalar.Quantizers;

[Quantizer(DataType.F16)]
public class QuantizerF16 : IQuantizer
{
    public unsafe void Dequantize(IntPtr srcPointer, Span<float> dstSpan, int elementCount)
    {
        ushort* src = (ushort*)srcPointer;
        for (int i = 0; i < elementCount; i++)
        {
            dstSpan[i] = (float)BitConverter.UInt16BitsToHalf(src[i]);
        }
    }
}
