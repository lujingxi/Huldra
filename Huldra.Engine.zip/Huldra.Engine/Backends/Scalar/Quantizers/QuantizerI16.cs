﻿using Huldra.Engine.Core;
using Huldra.Engine.Quantization;

namespace Huldra.Engine.Backends.Scalar.Quantizers;

[Quantizer(DataType.I16)]
public class QuantizerI16 : IQuantizer
{
    public unsafe void Dequantize(IntPtr srcPointer, Span<float> dstSpan, int elementCount)
    {
        short* src = (short*)srcPointer;
        for (int i = 0; i < elementCount; i++)
        {
            dstSpan[i] = (float)src[i];
        }
    }
}
