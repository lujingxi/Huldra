﻿using Huldra.Engine.Core;
using Huldra.Engine.Quantization;

namespace Huldra.Engine.Backends.Scalar.Quantizers;

[Quantizer(DataType.Q8_K)]
public class QuantizerQ8K : IQuantizer
{
    public unsafe void Dequantize(IntPtr srcPointer, Span<float> dstSpan, int elementCount)
    {
        if (srcPointer == IntPtr.Zero) return;

        int blockSize = 256;
        int numBlocks = elementCount / blockSize;
        BlockQ8K* src = (BlockQ8K*)srcPointer;

        fixed (float* dst = dstSpan)
        {
            for (int ib = 0; ib < numBlocks; ib++)
            {
                float d = src[ib].D;

                // Block-level sanitization: Zero out ONLY this bad block!
                if (float.IsNaN(d) || float.IsInfinity(d))
                {
                    float* y_bad = dst + ib * blockSize;
                    for (int j = 0; j < blockSize; j++) y_bad[j] = 0f;
                    continue;
                }

                sbyte* quants = src[ib].Quants;
                float* y = dst + ib * blockSize;

                for (int j = 0; j < 256; j++)
                {
                    y[j] = d * quants[j];
                }
            }
        }
    }
}

