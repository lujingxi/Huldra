﻿using Huldra.Engine.Core;
using Huldra.Engine.Quantization;

namespace Huldra.Engine.Backends.Scalar.Quantizers;

[Quantizer(DataType.Q6_K)]
public class QuantizerQ6K : IQuantizer
{
    public unsafe void Dequantize(IntPtr srcPointer, Span<float> dstSpan, int elementCount)
    {
        if (srcPointer == IntPtr.Zero) return;

        int blockSize = 256;
        int nb = elementCount / blockSize;
        BlockQ6K* x = (BlockQ6K*)srcPointer;

        fixed (float* y = dstSpan)
        {
            for (int i = 0; i < nb; i++)
            {
                float d = (float)BitConverter.UInt16BitsToHalf(x[i].D);
                byte* ql = x[i].Ql;
                byte* qh = x[i].Qh;
                sbyte* sc = x[i].Scales;

                float* y_i = y + i * blockSize;

                for (int n = 0; n < blockSize; n += 128)
                {
                    int n_half = n / 128;
                    byte* ql_ptr = ql + n_half * 64;
                    byte* qh_ptr = qh + n_half * 32;
                    sbyte* sc_ptr = sc + n_half * 8;

                    float* y_ptr = y_i + n;

                    for (int l = 0; l < 32; ++l)
                    {
                        int isVal = l / 16;

                        sbyte q1 = (sbyte)(((ql_ptr[l + 0] & 0x0F) | ((qh_ptr[l] & 0x03) << 4)) - 32);
                        sbyte q2 = (sbyte)(((ql_ptr[l + 32] & 0x0F) | ((qh_ptr[l] & 0x0C) << 2)) - 32);
                        sbyte q3 = (sbyte)(((ql_ptr[l + 0] >> 4) | ((qh_ptr[l] & 0x30) >> 0)) - 32);
                        sbyte q4 = (sbyte)(((ql_ptr[l + 32] >> 4) | ((qh_ptr[l] & 0xC0) >> 2)) - 32);

                        y_ptr[l + 0] = d * sc_ptr[isVal + 0] * q1;
                        y_ptr[l + 32] = d * sc_ptr[isVal + 2] * q2;
                        y_ptr[l + 64] = d * sc_ptr[isVal + 4] * q3;
                        y_ptr[l + 96] = d * sc_ptr[isVal + 6] * q4;
                    }
                }
            }
        }
    }
}
