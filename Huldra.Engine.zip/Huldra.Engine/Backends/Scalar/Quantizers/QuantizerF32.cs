﻿using Huldra.Engine.Core;
using Huldra.Engine.Quantization;

namespace Huldra.Engine.Backends.Scalar.Quantizers;

[Quantizer(DataType.F32)]
public class QuantizerF32 : IQuantizer
{
    public DataType SupportedType => DataType.F32;

    public unsafe void Dequantize(IntPtr srcPointer, Span<float> dstSpan, int elementCount)
    {
        float* src = (float*)srcPointer;
        for (int i = 0; i < elementCount; i++)
        {
            dstSpan[i] = src[i];
        }
    }
}
