﻿using Huldra.Engine.Core;
using Huldra.Engine.Quantization;

namespace Huldra.Engine.Backends.Scalar.Quantizers;

[Quantizer(DataType.Q8_0)]
public class QuantizerQ80 : IQuantizer
{
    public unsafe void Dequantize(IntPtr srcPointer, Span<float> dstSpan, int elementCount)
    {
        int blockSize = 32;
        int numBlocks = elementCount / blockSize;

        // Updated to use the PascalCase block name
        BlockQ80* srcBlocks = (BlockQ80*)srcPointer;

        for (int i = 0; i < numBlocks; i++)
        {
            float scale = (float)srcBlocks[i].Delta;
            for (int j = 0; j < blockSize; j++)
            {
                dstSpan[i * blockSize + j] = srcBlocks[i].Quants[j] * scale;
            }
        }
    }
}
