﻿using Huldra.Engine.Core;
using Huldra.Engine.Quantization;

namespace Huldra.Engine.Backends.Scalar.Quantizers;

[Quantizer(DataType.Q4_K)]
public class QuantizerQ4K : IQuantizer
{
    public unsafe void Dequantize(IntPtr srcPointer, Span<float> dstSpan, int elementCount)
    {
        if (srcPointer == IntPtr.Zero) return;

        int blockSize = 256;
        int nb = elementCount / blockSize;
        BlockQ4K* x = (BlockQ4K*)srcPointer;

        fixed (float* y = dstSpan)
        {
            for (int i = 0; i < nb; i++)
            {
                // Global scales
                float d = (float)BitConverter.UInt16BitsToHalf(x[i].D);
                float dmin = (float)BitConverter.UInt16BitsToHalf(x[i].Dmin);

                byte* q = x[i].Quants;
                byte* scales = x[i].Scales;

                float* y_i = y + i * blockSize;

                // Dequantize 256 elements in two halves (128 each)
                int isVal = 0;
                for (int j = 0; j < blockSize; j += 64)
                {
                    // Safe 6-bit scale and min unpacking without sign extension bugs
                    byte sc0 = (byte)(scales[isVal + 0] & 0x3F);
                    byte sc1 = (byte)(scales[isVal + 1] & 0x3F);
                    byte sc2 = (byte)(scales[isVal + 2] & 0x3F);
                    byte sc3 = (byte)(scales[isVal + 3] & 0x3F);

                    byte m0 = (byte)((scales[isVal + 0] >> 6) | ((scales[isVal + 4] & 0x0F) << 2));
                    byte m1 = (byte)((scales[isVal + 1] >> 6) | ((scales[isVal + 5] & 0x0F) << 2));
                    byte m2 = (byte)((scales[isVal + 2] >> 6) | ((scales[isVal + 6] & 0x0F) << 2));
                    byte m3 = (byte)((scales[isVal + 3] >> 6) | ((scales[isVal + 7] & 0x0F) << 2));

                    float d0 = d * sc0; float min0 = dmin * m0;
                    float d1 = d * sc1; float min1 = dmin * m1;
                    float d2 = d * sc2; float min2 = dmin * m2;
                    float d3 = d * sc3; float min3 = dmin * m3;

                    for (int l = 0; l < 32; l += 16)
                    {
                        for (int k = 0; k < 16; k++)
                        {
                            byte q_val = q[l + k];
                            int q_low = q_val & 0x0F;
                            int q_high = q_val >> 4;

                            if (l == 0)
                            {
                                y_i[k + 0] = d0 * q_low - min0;
                                y_i[k + 32] = d2 * q_high - min2;
                            }
                            else
                            {
                                y_i[k + 16] = d1 * q_low - min1;
                                y_i[k + 48] = d3 * q_high - min3;
                            }
                        }
                    }

                    y_i += 64;
                    q += 32;
                    isVal += (j == 0) ? 4 : 4; // Move to next scale block
                }
            }
        }
    }
}
