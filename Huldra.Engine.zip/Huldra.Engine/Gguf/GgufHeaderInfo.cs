﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Huldra.Engine.Gguf;

public class GgufHeaderInfo
{
    public uint Version { get; set; }
    public ulong TensorCount { get; set; }
    public ulong MetadataKVCount { get; set; }
}
