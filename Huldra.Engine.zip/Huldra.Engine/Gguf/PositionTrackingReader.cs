﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Huldra.Engine.Gguf;

public class PositionTrackingReader : IDisposable
{
    private readonly BinaryReader _reader;
    public long Position { get; private set; }

    public PositionTrackingReader(Stream stream)
    {
        _reader = new BinaryReader(stream, Encoding.UTF8, leaveOpen: true);
        Position = 0;
    }

    public byte ReadByte() { Position += 1; return _reader.ReadByte(); }
    public sbyte ReadSByte() { Position += 1; return _reader.ReadSByte(); }
    public ushort ReadUInt16() { Position += 2; return _reader.ReadUInt16(); }
    public short ReadInt16() { Position += 2; return _reader.ReadInt16(); }
    public uint ReadUInt32() { Position += 4; return _reader.ReadUInt32(); }
    public int ReadInt32() { Position += 4; return _reader.ReadInt32(); }
    public ulong ReadUInt64() { Position += 8; return _reader.ReadUInt64(); }
    public long ReadInt64() { Position += 8; return _reader.ReadInt64(); }
    public float ReadSingle() { Position += 4; return _reader.ReadSingle(); }
    public double ReadDouble() { Position += 8; return _reader.ReadDouble(); }

    public byte[] ReadBytes(int count)
    {
        Position += count;
        return _reader.ReadBytes(count);
    }

    public void Dispose() => _reader.Dispose();
}
