﻿using Huldra.Engine.Core;

namespace Huldra.Engine.Gguf;

public class TensorInfo
{
    public string Name { get; set; } = string.Empty;
    public uint Dimensions { get; set; }
    public ulong[] Shape { get; set; } = [];
    public DataType Type { get; set; }
    public ulong Offset { get; set; }
    public long MaxByteSize { get; set; }
    public IntPtr DataPointer { get; set; }
}
