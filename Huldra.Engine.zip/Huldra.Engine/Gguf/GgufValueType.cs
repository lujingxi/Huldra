﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Huldra.Engine.Gguf;

/// <summary>
/// Represents the data types that can be stored in GGUF metadata key-value pairs.
/// Defined by the official GGUF specification.
/// </summary>
public enum GgufValueType : uint
{
    Uint8 = 0,
    Int8 = 1,
    Uint16 = 2,
    Int16 = 3,
    Uint32 = 4,
    Int32 = 5,
    Float32 = 6,
    Bool = 7,
    String = 8,
    Array = 9,
    Uint64 = 10,
    Int64 = 11,
    Float64 = 12
}
