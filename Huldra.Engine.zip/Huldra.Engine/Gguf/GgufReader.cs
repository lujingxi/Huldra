﻿using Huldra.Engine.Core;
using System;
using System.Collections.Generic;
using System.IO.MemoryMappedFiles;
using System.Text;

namespace Huldra.Engine.Gguf;

/// <summary>
/// A fast binary parser for reading GGUF file headers and metadata.
/// </summary>
/// <summary>
/// A wrapper around BinaryReader that tracks exact byte position, 
/// bypassing BinaryReader's internal stream-buffering drift.
/// </summary>
public class GgufReader : IDisposable
{
    private readonly PositionTrackingReader _reader;
    private readonly FileStream _stream;
    private const uint GgufMagic = 0x46554747;

    public GgufHeaderInfo Header { get; private set; } = new();
    public Dictionary<string, object> Metadata { get; } = new(StringComparer.Ordinal);
    public List<TensorInfo> Tensors { get; } = [];

    private MemoryMappedFile? _mmapFile;
    private readonly List<MemoryMappedViewAccessor> _tensorViews = new();

    public GgufReader(string filePath)
    {
        if (!File.Exists(filePath))
            throw new FileNotFoundException($"Model file not found: {filePath}");

        _stream = new FileStream(filePath, FileMode.Open, FileAccess.Read, FileShare.Read, 4096, FileOptions.SequentialScan);
        _reader = new PositionTrackingReader(_stream);
    }

    public void Parse()
    {
        uint magic = _reader.ReadUInt32();
        if (magic != GgufMagic) throw new InvalidDataException("Invalid GGUF Magic Number.");

        Header = new GgufHeaderInfo
        {
            Version = _reader.ReadUInt32(),
            TensorCount = _reader.ReadUInt64(),
            MetadataKVCount = _reader.ReadUInt64()
        };
        if (Header.Version < 2) throw new NotSupportedException($"GGUF version v{Header.Version} is not supported.");

        for (ulong i = 0; i < Header.MetadataKVCount; i++)
        {
            string key = ReadString();
            var valueType = (GgufValueType)_reader.ReadUInt32();
            Metadata[key] = ReadValue(valueType);
        }

        for (ulong i = 0; i < Header.TensorCount; i++)
        {
            string name = ReadString();
            uint nDims = _reader.ReadUInt32();
            ulong[] shape = new ulong[nDims];
            for (int d = 0; d < nDims; d++)
            {
                shape[d] = _reader.ReadUInt64();
            }
            uint type = _reader.ReadUInt32();
            ulong offset = _reader.ReadUInt64();

            Tensors.Add(new TensorInfo
            {
                Name = name,
                Dimensions = nDims,
                Shape = shape,
                Type = (DataType)type,
                Offset = offset
            });
        }

        uint alignment = GetMetadata<uint>("general.alignment");
        if (alignment == 0) alignment = 32;

        long currentPos = _reader.Position;
        long padding = (currentPos % alignment == 0) ? 0 : alignment - (currentPos % alignment);
        long dataStartOffset = currentPos + padding;

        Console.WriteLine($"[GgufReader Debug] Header+Metadata size: {currentPos} bytes. Data starts at exact offset: {dataStartOffset} bytes.");

        InitializeTensorMmaps(dataStartOffset);
    }

    private unsafe void InitializeTensorMmaps(long dataStartOffset)
    {
        _mmapFile = MemoryMappedFile.CreateFromFile(
            _stream, null, 0, MemoryMappedFileAccess.Read, HandleInheritability.None, false);

        foreach (var tInfo in Tensors)
        {
            int rowLength = (int)tInfo.Shape[0];

            long numRows = 1;
            for (int d = 1; d < tInfo.Shape.Length; d++)
            {
                numRows *= (long)tInfo.Shape[d];
            }

            long bytesPerRow = TensorHelper.CalculateRowStrideBytes(tInfo.Type, rowLength);
            long tensorSizeBytes = numRows * bytesPerRow;
            long absoluteOffset = dataStartOffset + (long)tInfo.Offset;

            // Calculate exact available physical bytes in file
            long availableBytesInFile = Math.Max(0, _stream.Length - absoluteOffset);
            long actualViewSize = Math.Min(tensorSizeBytes, availableBytesInFile);

            // CRITICAL FIX: Store the EXACT physical MMAP view capacity!
            tInfo.MaxByteSize = actualViewSize;

            if (actualViewSize > 0)
            {
                var view = _mmapFile.CreateViewAccessor(absoluteOffset, actualViewSize, MemoryMappedFileAccess.Read);
                byte* ptr = null;
                view.SafeMemoryMappedViewHandle.AcquirePointer(ref ptr);

                tInfo.DataPointer = (IntPtr)ptr;
                _tensorViews.Add(view);
            }
            else
            {
                tInfo.DataPointer = IntPtr.Zero;
            }
        }

        Console.WriteLine($"[GgufReader Debug] Created {Tensors.Count} dedicated MMAP views with exact physical view capacity locking.");
    }

    public IntPtr GetTensorDataPointer(TensorInfo tensor) => tensor.DataPointer;

    private string ReadString()
    {
        ulong length = _reader.ReadUInt64();
        byte[] bytes = _reader.ReadBytes((int)length);
        return Encoding.UTF8.GetString(bytes);
    }

    private object ReadValue(GgufValueType type)
    {
        return type switch
        {
            GgufValueType.Uint8 => _reader.ReadByte(),
            GgufValueType.Int8 => _reader.ReadSByte(),
            GgufValueType.Uint16 => _reader.ReadUInt16(),
            GgufValueType.Int16 => _reader.ReadInt16(),
            GgufValueType.Uint32 => _reader.ReadUInt32(),
            GgufValueType.Int32 => _reader.ReadInt32(),
            GgufValueType.Float32 => _reader.ReadSingle(),
            GgufValueType.Float64 => _reader.ReadDouble(),
            GgufValueType.Uint64 => _reader.ReadUInt64(),
            GgufValueType.Int64 => _reader.ReadInt64(),
            GgufValueType.Bool => _reader.ReadByte() != 0,
            GgufValueType.String => ReadString(),
            GgufValueType.Array => ReadArray(),
            _ => throw new NotSupportedException($"Unsupported GGUF type: {type}")
        };
    }

    private object ReadArray()
    {
        var arrayType = (GgufValueType)_reader.ReadUInt32();
        ulong length = _reader.ReadUInt64();
        var array = new object[length];
        for (ulong i = 0; i < length; i++) array[i] = ReadValue(arrayType);
        return array;
    }

    public T? GetMetadata<T>(string key)
    {
        if (Metadata.TryGetValue(key, out var value) && value is T typedValue)
            return typedValue;
        return default;
    }

    public unsafe void Dispose()
    {
        foreach (var view in _tensorViews)
        {
            view.SafeMemoryMappedViewHandle.ReleasePointer();
            view.Dispose();
        }
        _tensorViews.Clear();

        _mmapFile?.Dispose();
        _reader.Dispose();
        _stream.Dispose();
    }
}
