﻿namespace Huldra.Engine.Sampling;

/// <summary>
/// Provides advanced sampling strategies (Temperature, Top-P, ArgMax) for next-token prediction.
/// </summary>
public static class LlmSampler
{
    /// <summary>
    /// Samples a token ID from raw logits using Temperature scaling and Top-P (Nucleus) sampling.
    /// </summary>
    public static int Sample(Span<float> logits, float temperature = 0.7f, float topP = 0.9f)
    {
        int vocabSize = logits.Length;

        // 1. Temperature Scaling (If temp <= 0, fallback to pure ArgMax)
        if (temperature <= 0.0f)
        {
            int maxIdx = 0;
            float maxLogit = float.MinValue;
            for (int i = 0; i < vocabSize; i++)
            {
                if (logits[i] > maxLogit)
                {
                    maxLogit = logits[i];
                    maxIdx = i;
                }
            }
            return maxIdx;
        }

        // Apply Temperature
        Span<float> scaledLogits = stackalloc float[vocabSize];
        float invTemp = 1.0f / temperature;
        float maxVal = float.MinValue;

        for (int i = 0; i < vocabSize; i++)
        {
            float val = logits[i] * invTemp;
            scaledLogits[i] = val;
            if (val > maxVal) maxVal = val;
        }

        // 2. Compute Softmax Probabilities
        float sumExp = 0f;
        for (int i = 0; i < vocabSize; i++)
        {
            float expVal = MathF.Exp(scaledLogits[i] - maxVal);
            scaledLogits[i] = expVal;
            sumExp += expVal;
        }

        float invSum = 1.0f / sumExp;
        for (int i = 0; i < vocabSize; i++)
        {
            scaledLogits[i] *= invSum;
        }

        // 3. Top-P (Nucleus) Filtering & Cumulative Probability Sampling
        var candidates = new (int Id, float Prob)[vocabSize];
        for (int i = 0; i < vocabSize; i++)
        {
            candidates[i] = (i, scaledLogits[i]);
        }

        // Sort descending by probability
        Array.Sort(candidates, (a, b) => b.Prob.CompareTo(a.Prob));

        float cumSum = 0f;
        int cutoffCount = 0;
        for (int i = 0; i < vocabSize; i++)
        {
            cumSum += candidates[i].Prob;
            cutoffCount++;
            if (cumSum >= topP) break;
        }

        // Random selection from Nucleus pool
        float randomVal = Random.Shared.NextSingle() * cumSum;
        float runningSum = 0f;

        for (int i = 0; i < cutoffCount; i++)
        {
            runningSum += candidates[i].Prob;
            if (randomVal <= runningSum)
            {
                return candidates[i].Id;
            }
        }

        return candidates[0].Id;
    }
}
